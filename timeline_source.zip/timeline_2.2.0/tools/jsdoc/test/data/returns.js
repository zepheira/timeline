
/** 
 * The separator character. 
 * @return	{Array,
			String}
 */
 
function processText(text, processor) {
	return processor(text);
}
﻿/** @constructor */
function RecordSet() {
    /** Get all the records. */
    this.getRecords = function(){
    }
}

/*
[
    {
        symbols: [
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "CONSTRUCTOR",
                desc: "",
                alias: "RecordSet",
                memberof: "",
                params: [],
                methods: [ { name: "getRecords", alias: "RecordSet.getRecords" } ],
                name: "RecordSet"
            },
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "FUNCTION",
                desc: "Get all the records.",
                alias: "RecordSet.getRecords",
                memberof: "RecordSet",
                params: [],
                methods: [],
                name: "getRecords"
            }
        ],
        overview: {
            doc: { tags: [] },
            returns: [],
            type: "",
            properties: [],
            isa: "FILE",
            desc: "No overview provided.",
            alias: "examples/data/methods2.js",
            memberof: "",
            params: [],
            methods: [],
            name: "examples/data/methods2.js"
        }
    }
]
*/